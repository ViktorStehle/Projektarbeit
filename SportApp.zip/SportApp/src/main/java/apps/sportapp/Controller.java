package apps.sportapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import static apps.sportapp.BackEnd.*;


public class Controller implements Initializable {

    @FXML
    private ChoiceBox<String> sportart;

    @FXML
    protected DatePicker datePicker;

    @FXML
    private ListView<String> listOfEvents;

    @FXML
    private Text schritteOut;

    @FXML
    private TextField schritteIn;

    @FXML
    private TextField verbrauchIn;

    @FXML
    private Text verbrauchOut;

    @FXML
    private TextField zunahmeIn;

    @FXML
    private Text zunahmeOut;

    private User currentUser = new User(1, "test", "test", 60);;

    @FXML
    void löscheData(MouseEvent event) {
        int selectedID = listOfEvents.getSelectionModel().getSelectedIndex();
        listOfEvents.getItems().remove(selectedID);

        String selected = stringList.get(selectedID);
        System.out.println(selected);
        String[] delete = selected.split(", ");
        for (String s : delete) {
            System.out.println(s);
        }
        LocalDate date = LocalDate.parse(delete[4]);
        currentUser.deleteFromDays(date, Integer.parseInt(delete[2]),Integer.parseInt(delete[0]),Integer.parseInt(delete[1]));

        for(int i = 0; i < currentUser.days.length; i++){
            System.out.println(i+". Tag, Datum "+currentUser.days[i].date);
            System.out.println(i+". Tag, Schritte "+currentUser.days[i].schritte);
            System.out.println(i+". Tag, kalStand "+currentUser.days[i].kalStand);
        }

        deleteString(selectedID);
    }

    @FXML
    void saveData(MouseEvent event) {
        LocalDate time = datePicker.getValue();
        String sport = sportart.getSelectionModel().getSelectedItem();
        listOfEvents.getItems().add(zunahmeIn.getText()+", " + verbrauchIn.getText()+ ", " + schritteIn.getText() + ", " + sport + "," + time);
        saveString(zunahmeIn.getText()+", " + verbrauchIn.getText()+ ", " + schritteIn.getText() + ", " + sport + ", " + time);

        currentUser.setDays(time, Integer.parseInt(schritteIn.getText()), Integer.parseInt(zunahmeIn.getText()),Integer.parseInt(verbrauchIn.getText()));
        System.out.println("Länge day-array: "+currentUser.days.length);
        for(int i = 0; i < currentUser.days.length; i++){
            System.out.println(i+". Tag, Datum "+currentUser.days[i].date);
            System.out.println(i+". Tag, Schritte "+currentUser.days[i].schritte);
            System.out.println(i+". Tag, kalStand "+currentUser.days[i].kalStand);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        sportart.getItems().addAll("Ausdauersport", "Kraftsport", "Kampfsport", "Bettsport", "Kopfsport");
    }
}

